module.exports = [
    {
        'title': 'Колок',
        'content': 'Затащить на пятюню',
        'color': 'yellow',
        'group': 'priority'
    }, 

    {
        'title': 'Практика по фронтенду',
        'content': 'Написать убийцу Google Keep',
        'color': 'red',
        'group': 'priority'
    },

    {
        'title': 'Картинка',
        'content': 'krasivo',
        'color': 'orange',
        'image': 'krasivo.jpg',
        'group': 'priority'
    },

    {
        'title': 'Вынести мусор',
        'content': 'Не забыть смешную шутку',
        'image': 'pomoika.jpg',
        'color': 'yellow',
        'group': 'normal'
    },

    {
        'title': 'Вынести мусор',
        'content': 'Не забыть смешную шутку',
        'image': 'pomoika.jpg',
        'color': 'orange',
        'group': 'normal'
    },

    {
        'title': 'Вынести мусор',
        'content': 'Не забыть смешную шутку',
        'image': 'pomoika.jpg',
        'color': 'red',
        'group': 'normal'
    },

    {
        'title': 'Вынести мусор',
        'content': 'Не забыть смешную шутку',
        'image': 'pomoika.jpg',
        'color': 'blue',
        'group': 'normal'
    }, 

    {
        'title': 'Найти идеи',
        'content': 'помогите у меня нет сил придумывать эти тексты',
        'color': 'blue',
        'group': 'normal'
    }
]